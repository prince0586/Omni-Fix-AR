import React from 'react';

export const ThinkingIndicator: React.FC<{ message: string }> = ({ message }) => {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm z-50">
      <div className="relative w-24 h-24 mb-6">
        <div className="absolute top-0 left-0 w-full h-full border-4 border-cyan-500/30 rounded-full"></div>
        <div className="absolute top-0 left-0 w-full h-full border-4 border-transparent border-t-cyan-500 rounded-full animate-spin"></div>
        <div className="absolute top-4 left-4 w-16 h-16 border-4 border-purple-500/30 rounded-full"></div>
        <div className="absolute top-4 left-4 w-16 h-16 border-4 border-transparent border-b-purple-500 rounded-full animate-spin-slow"></div>
      </div>
      <h2 className="text-xl font-bold text-white tracking-widest animate-pulse">{message}</h2>
      <p className="text-cyan-400/70 text-sm mt-2 font-mono">GEMINI 3 PRO PREVIEW</p>
    </div>
  );
};
