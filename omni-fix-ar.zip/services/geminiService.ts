import { GoogleGenAI, Type, Schema } from "@google/genai";
import { RepairPlan, GeminiRepairResponse, ComponentInfo } from "../types";

const MODEL_NAME = "gemini-3-pro-preview"; // Using 3 Pro Preview for Thinking capabilities

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const repairSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    object_name: {
      type: Type.STRING,
      description: "Name of the object identified (e.g., 'Espresso Machine', 'Bicycle Wheel')."
    },
    issue_diagnosis: {
      type: Type.STRING,
      description: "A concise diagnosis of the problem based on visual cues."
    },
    steps: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "Short title of the step" },
          instruction: { type: Type.STRING, description: "Clear, actionable instruction." },
          tool_needed: { type: Type.STRING, description: "Tool required for this step, if any." },
          safety_warning: { type: Type.STRING, description: "CRITICAL: Any safety risks? e.g. 'Hot Surface', 'High Voltage', 'Sharp'. Leave empty if safe." },
          visual_cue: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING, enum: ["box", "arrow", "point", "none"], description: "The type of AR overlay to draw." },
              ymin: { type: Type.NUMBER, description: "Bounding box ymin (0-100 scale)" },
              xmin: { type: Type.NUMBER, description: "Bounding box xmin (0-100 scale)" },
              ymax: { type: Type.NUMBER, description: "Bounding box ymax (0-100 scale)" },
              xmax: { type: Type.NUMBER, description: "Bounding box xmax (0-100 scale)" },
              label: { type: Type.STRING, description: "Short label to display on the overlay." },
              direction: { type: Type.STRING, description: "Direction of movement if applicable (e.g. 'clockwise')" }
            },
            required: ["type", "ymin", "xmin", "ymax", "xmax"]
          }
        },
        required: ["title", "instruction", "visual_cue"]
      }
    }
  },
  required: ["object_name", "issue_diagnosis", "steps"]
};

const componentInfoSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "Technical name of the component." },
    function: { type: Type.STRING, description: "What does this component do?" },
    status: { type: Type.STRING, enum: ["Good", "Damaged", "Unknown"], description: "Visual condition." },
    details: { type: Type.STRING, description: "Brief visual analysis details." }
  },
  required: ["name", "function", "status", "details"]
};

export const analyzeImageAndCreatePlan = async (base64Image: string): Promise<RepairPlan> => {
  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image
            }
          },
          {
            text: `You are Omni-Fix, an expert repair AI. 
            1. Analyze the image to identify the object and the likely problem.
            2. Create a step-by-step repair plan.
            3. CRITICAL: Identify any SAFETY HAZARDS for each step.
            4. For the FIRST STEP, provide precise coordinates (0-100 scale) for an AR overlay.
            Think deeply about the mechanics and safety.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: repairSchema,
        thinkingConfig: { thinkingBudget: 2048 },
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");

    const parsed: GeminiRepairResponse = JSON.parse(text);

    // Map to internal type
    const plan: RepairPlan = {
      objectName: parsed.object_name,
      issueDiagnosis: parsed.issue_diagnosis,
      steps: parsed.steps.map((s, i) => ({
        id: i,
        title: s.title,
        instruction: s.instruction,
        toolNeeded: s.tool_needed,
        safetyWarning: s.safety_warning,
        visualCue: {
          type: s.visual_cue.type as any,
          coordinates: {
            ymin: s.visual_cue.ymin,
            xmin: s.visual_cue.xmin,
            ymax: s.visual_cue.ymax,
            xmax: s.visual_cue.xmax
          },
          label: s.visual_cue.label,
          direction: s.visual_cue.direction
        }
      }))
    };

    return plan;

  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};

export const verifyRepairStep = async (base64Image: string, currentStepInstruction: string): Promise<{ completed: boolean; feedback: string }> => {
  const verifySchema: Schema = {
    type: Type.OBJECT,
    properties: {
      completed: { type: Type.BOOLEAN },
      feedback: { type: Type.STRING }
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash", 
      contents: {
        parts: [
          { inlineData: { mimeType: "image/jpeg", data: base64Image } },
          { text: `The user was asked to perform this step: "${currentStepInstruction}". Look at the image. Is this step completed? Return JSON.` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: verifySchema
      }
    });
    
    const text = response.text;
    if(!text) return { completed: false, feedback: "Could not verify." };
    return JSON.parse(text);
  } catch (e) {
    console.error(e);
    return { completed: false, feedback: "Error during verification." };
  }
};

export const askRepairAssistant = async (
  base64Image: string, 
  base64Audio: string, 
  currentStepInstruction: string
): Promise<string> => {
  try {
    // Using 2.5 Flash for fast multimodal audio/visual reasoning
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          { inlineData: { mimeType: "image/jpeg", data: base64Image } },
          { inlineData: { mimeType: "audio/wav", data: base64Audio } }, // Assuming recorded as WAV or compatible
          { text: `You are a helpful repair assistant. The user is currently on this step: "${currentStepInstruction}". 
                   Listen to their question or the sound of the machine. Provide a short, helpful, conversational answer (max 2 sentences).` }
        ]
      }
    });
    return response.text || "I couldn't hear that clearly, could you repeat?";
  } catch (e) {
    console.error(e);
    return "Sorry, I had trouble processing that.";
  }
};

export const identifyComponentAtPoint = async (
  base64Image: string, 
  x: number, 
  y: number, 
  objectContext: string
): Promise<ComponentInfo> => {
  try {
    // Create a 2D pointing prompt using 0-1000 scale expected by the model for spatial reasoning mostly, 
    // but here we describe the point textually for robustness across models or map it.
    // 3 Pro Preview handles spatial understanding very well.
    // Coordinates passed are 0-100 (percentage) from the app.
    
    const y_norm = Math.round(y * 10); // 0-1000
    const x_norm = Math.round(x * 10); // 0-1000

    const response = await ai.models.generateContent({
      model: MODEL_NAME, // 3 Pro for deep knowledge
      contents: {
        parts: [
          { inlineData: { mimeType: "image/jpeg", data: base64Image } },
          { text: `I am pointing at the component located approximately at [${y_norm}, ${x_norm}] (on a 1000x1000 grid). 
                   The overall object is a ${objectContext}.
                   Identify this specific component, its function, and check if it looks visually damaged.
                   Be technical but accessible.` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: componentInfoSchema,
        thinkingConfig: { thinkingBudget: 1024 } // Small thinking budget for accuracy
      }
    });

    const text = response.text;
    if(!text) throw new Error("No ID");
    return JSON.parse(text);

  } catch (e) {
    console.error(e);
    return { name: "Unknown", function: "Could not identify", status: "Unknown", details: "Try again." };
  }
}