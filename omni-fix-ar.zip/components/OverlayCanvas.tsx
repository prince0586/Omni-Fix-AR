import React from 'react';
import { VisualCue } from '../types';

interface OverlayCanvasProps {
  cue: VisualCue;
  width: number;
  height: number;
}

const OverlayCanvas: React.FC<OverlayCanvasProps> = ({ cue, width, height }) => {
  if (cue.type === 'none') return null;

  // Convert 0-100 percentage coordinates to pixels
  const x = (cue.coordinates.xmin / 100) * width;
  const y = (cue.coordinates.ymin / 100) * height;
  const w = ((cue.coordinates.xmax - cue.coordinates.xmin) / 100) * width;
  const h = ((cue.coordinates.ymax - cue.coordinates.ymin) / 100) * height;

  const cx = x + w / 2;
  const cy = y + h / 2;

  return (
    <svg 
      className="absolute top-0 left-0 w-full h-full pointer-events-none z-20" 
      viewBox={`0 0 ${width} ${height}`}
      style={{ overflow: 'visible' }}
    >
      <defs>
        <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
          <polygon points="0 0, 10 3.5, 0 7" fill="#00ffcc" />
        </marker>
        <filter id="neon-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
            <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
            </feMerge>
        </filter>
      </defs>

      {cue.type === 'box' && (
        <g filter="url(#neon-glow)">
          <rect 
            x={x} y={y} width={w} height={h} 
            fill="none" stroke="#00ffcc" strokeWidth="3" 
            rx="4" strokeDasharray="10, 5"
            className="animate-pulse"
          />
          {cue.label && (
             <text x={x} y={y - 10} fill="#00ffcc" fontSize="16" fontWeight="bold" fontFamily="monospace">
               {cue.label}
             </text>
          )}
        </g>
      )}

      {cue.type === 'arrow' && (
        <g filter="url(#neon-glow)">
           {/* Simple arrow pointing to center of region */}
           <line 
             x1={cx - 50} y1={cy + 50} 
             x2={cx} y2={cy} 
             stroke="#00ffcc" strokeWidth="4" 
             markerEnd="url(#arrowhead)" 
           />
           {cue.label && (
             <text x={cx - 60} y={cy + 70} fill="#00ffcc" fontSize="16" fontWeight="bold" fontFamily="monospace">
               {cue.label}
             </text>
          )}
        </g>
      )}

      {cue.type === 'point' && (
        <g filter="url(#neon-glow)">
          <circle cx={cx} cy={cy} r={10} fill="none" stroke="#00ffcc" strokeWidth="2" className="animate-ping" />
          <circle cx={cx} cy={cy} r={5} fill="#00ffcc" />
          <line x1={cx} y1={cy} x2={cx + 30} y2={cy - 30} stroke="#00ffcc" strokeWidth="1" />
           {cue.label && (
             <text x={cx + 35} y={cy - 35} fill="#00ffcc" fontSize="14" fontWeight="bold" fontFamily="monospace">
               {cue.label}
             </text>
          )}
        </g>
      )}
    </svg>
  );
};

export default OverlayCanvas;