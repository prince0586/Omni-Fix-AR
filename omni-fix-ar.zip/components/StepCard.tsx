import React from 'react';
import { RepairStep } from '../types';
import { CheckCircle2, AlertTriangle, Wrench, Mic, Volume2 } from 'lucide-react';

interface StepCardProps {
  step: RepairStep;
  totalSteps: number;
  currentStepIndex: number;
  onVerify: () => void;
  onNext: () => void;
  isVerifying: boolean;
  onAskAssistantStart: () => void;
  onAskAssistantStop: () => void;
  isListening: boolean;
  assistantResponse?: string | null;
}

const StepCard: React.FC<StepCardProps> = ({ 
  step, 
  totalSteps, 
  currentStepIndex, 
  onVerify, 
  onNext, 
  isVerifying,
  onAskAssistantStart,
  onAskAssistantStop,
  isListening,
  assistantResponse
}) => {
  return (
    <div className="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black via-black/95 to-transparent z-40 pb-6">
      <div className="max-w-md mx-auto relative">
        
        {/* Safety Warning Banner */}
        {step.safetyWarning && (
            <div className="mb-3 bg-red-900/80 border border-red-500/50 rounded-lg p-3 flex items-start gap-3 animate-pulse">
                <AlertTriangle className="text-red-400 shrink-0" size={20} />
                <div className="text-xs text-red-100">
                    <span className="font-bold uppercase block text-red-400">Safety Alert</span>
                    {step.safetyWarning}
                </div>
            </div>
        )}

        {/* Main Card */}
        <div className="bg-gray-900/90 border border-gray-700 backdrop-blur-md rounded-2xl p-5 shadow-2xl">
            <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                Step {currentStepIndex + 1} / {totalSteps}
            </span>
            {step.toolNeeded && (
                <div className="flex items-center gap-1 text-amber-400 text-xs font-medium px-2 py-1 bg-amber-950/50 rounded-full border border-amber-900/50">
                <Wrench size={12} />
                <span>{step.toolNeeded}</span>
                </div>
            )}
            </div>

            <h3 className="text-lg font-bold text-white mb-1 leading-tight">{step.title}</h3>
            <p className="text-gray-300 text-sm mb-4 leading-relaxed">{step.instruction}</p>

            {/* Assistant Response Bubble */}
            {assistantResponse && (
                <div className="mb-4 p-3 bg-cyan-950/50 border border-cyan-800 rounded-lg flex gap-2 items-center">
                    <Volume2 size={16} className="text-cyan-400 shrink-0" />
                    <p className="text-cyan-100 text-xs italic">"{assistantResponse}"</p>
                </div>
            )}

            <div className="flex gap-3 items-stretch">
                {/* Sonic Assistant Button */}
                <button
                    onMouseDown={onAskAssistantStart}
                    onMouseUp={onAskAssistantStop}
                    onTouchStart={onAskAssistantStart}
                    onTouchEnd={onAskAssistantStop}
                    className={`px-4 rounded-lg flex items-center justify-center transition-all border
                        ${isListening 
                            ? 'bg-red-600 border-red-500 text-white scale-95 shadow-[0_0_15px_rgba(220,38,38,0.5)]' 
                            : 'bg-gray-800 border-gray-600 text-gray-300 hover:bg-gray-700'}`}
                >
                    <Mic size={20} className={isListening ? "animate-pulse" : ""} />
                </button>

                <button 
                    onClick={onVerify}
                    disabled={isVerifying || isListening}
                    className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-semibold transition-all
                    ${isVerifying 
                        ? 'bg-gray-700 text-gray-400 cursor-not-allowed' 
                        : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-900/50 active:scale-95'}`}
                >
                    {isVerifying ? (
                    <span className="animate-pulse">Checking...</span>
                    ) : (
                    <>
                        <CheckCircle2 size={18} />
                        <span>Verify</span>
                    </>
                    )}
                </button>
                
                <button 
                    onClick={onNext}
                    className="px-4 py-3 bg-gray-800 hover:bg-gray-700 border border-gray-600 rounded-lg text-gray-300 font-medium transition-colors"
                >
                    Skip
                </button>
            </div>
            <div className="text-[10px] text-center text-gray-600 mt-2 font-mono">
                Hold Mic to ask Gemini
            </div>
        </div>
      </div>
    </div>
  );
};

export default StepCard;